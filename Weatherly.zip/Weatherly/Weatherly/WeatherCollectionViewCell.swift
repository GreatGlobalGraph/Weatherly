//
//  WeatherCollectionViewCell.swift
//  Weatherly
//
//  Created by Kishan on 17/08/19.
//  Copyright © 2019 Kishan. All rights reserved.
//

import UIKit

class WeatherCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var time: UILabel!
    
}
